import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class CheckoutServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String phone = request.getParameter("phone");
        out.println("<h2>Order Confirmed</h2>");
        out.println("<p>Name: " + name + "</p>");
        out.println("<p>Address: " + address + "</p>");
        out.println("<p>Phone: " + phone + "</p>");
        out.println("<p>Thank you for shopping!</p>");
    }
}