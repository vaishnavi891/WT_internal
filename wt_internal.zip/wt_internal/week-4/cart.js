let cart = JSON.parse(localStorage.getItem("cart")) || [];

function addToCart(name, price) {
    cart.push({name, price});
    localStorage.setItem("cart", JSON.stringify(cart));
    alert(name + " added to cart");
}

function displayCart() {
    let cartData = JSON.parse(localStorage.getItem("cart")) || [];
    let output = "";

    if (cartData.length === 0) {
        output = "Cart is empty";
    } else {
        let total = 0;
        output = "<ul>";

        cartData.forEach(item => {
            output += "<li>" + item.name + " - ₹" + item.price + "</li>";
            total += item.price;
        });

        output += "</ul>";
        output += "<h3>Total: ₹" + total + "</h3>";
    }

    document.getElementById("cartItems").innerHTML = output;
}