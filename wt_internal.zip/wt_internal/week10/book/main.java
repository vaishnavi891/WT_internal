package week10.book;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import java.util.List;

public class main {

    public static void main(String[] args) {

        SessionFactory factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();

        // -------- CREATE --------
        Transaction t1 = session.beginTransaction();

        Book b = new Book();
        b.setTitle("Java");
        b.setAuthor("James");
        b.setPrice(500);

        session.save(b);
        t1.commit();

        System.out.println("Book Added");

        // -------- READ --------
        List<Book> list = session.createQuery("from Book", Book.class).list();

        for(Book bk : list){
            System.out.println(bk.getId()+" "+bk.getTitle()+" "+bk.getAuthor()+" "+bk.getPrice());
        }

        // -------- UPDATE --------
        Transaction t2 = session.beginTransaction();

        Book updateBook = session.get(Book.class, 1);
        if(updateBook != null){
            updateBook.setPrice(800);
            session.update(updateBook);
        }

        t2.commit();
        System.out.println("Book Updated");

        // -------- DELETE --------
        Transaction t3 = session.beginTransaction();

        Book deleteBook = session.get(Book.class, 1);
        if(deleteBook != null){
            session.delete(deleteBook);
        }

        t3.commit();
        System.out.println("Book Deleted");

        session.close();
    }
}