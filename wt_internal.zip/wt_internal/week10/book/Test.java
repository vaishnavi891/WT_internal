package week10.book;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class Test {
    public static void main(String[] args) {

        SessionFactory factory = new Configuration().configure().buildSessionFactory();
        Session session = factory.openSession();

        Transaction t = session.beginTransaction();

        // -------- Book --------
        Book b = new Book();
        b.setTitle("Hibernate");
        b.setAuthor("Gavin King");
        b.setPrice(600);

        session.save(b);

        // -------- User --------
        User u = new User();
        u.setUsername("admin");
        u.setPassword("123");

        session.save(u);

        // Commit
        t.commit();
        session.close();

        System.out.println("Book and User Data Saved");
    }
}