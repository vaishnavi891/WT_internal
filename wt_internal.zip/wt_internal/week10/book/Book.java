package week10.book;
import javax.persistence.*;
@Entity
@Table(name="books")
public class Book {

    @Id
    private int id;

    private String title;
    private String author;
    private int price;

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public int getPrice() { return price; }
    public void setPrice(int price) { this.price = price; }
}