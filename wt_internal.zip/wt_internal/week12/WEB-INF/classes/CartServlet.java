import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CartServlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession();

        ArrayList<String> cart =
            (ArrayList<String>) session.getAttribute("cart");

        if(cart == null) {
            cart = new ArrayList<String>();
        }

        // If book is passed → add item
        String book = request.getParameter("book");
        if(book != null) {
            cart.add(book);
        }

        session.setAttribute("cart", cart);

        // Display cart
        if(cart.size() == 0) {
            out.println("<p>Cart is empty</p>");
        } else {
            for(String item : cart) {
                out.println("<p>" + item + "</p>");
            }
        }
    }
}