<h2>Shipping Details</h2>

<form action="checkout" method="post">

Name: <input type="text" name="name"><br><br>
Address: <input type="text" name="address"><br><br>
Phone: <input type="text" name="phone"><br><br>

<input type="submit" value="Place Order">

</form>