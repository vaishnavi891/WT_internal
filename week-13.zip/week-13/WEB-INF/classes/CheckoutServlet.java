import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession();

        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String phone = request.getParameter("phone");

        ArrayList<String> cart =
            (ArrayList<String>) session.getAttribute("cart");

        out.println("<h2>Order Placed Successfully</h2>");

        out.println("<h3>Details</h3>");
        out.println("Name: " + name + "<br>");
        out.println("Address: " + address + "<br>");
        out.println("Phone: " + phone + "<br><br>");

        out.println("<h3>Items:</h3>");

        if (cart != null) {
            for (String item : cart) {
                out.println(item + "<br>");
            }
        }

        session.removeAttribute("cart");

        out.println("<br><a href='cart.jsp'>Back to Cart</a>");
    }
}