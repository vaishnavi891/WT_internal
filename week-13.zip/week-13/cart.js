function addToCart(item) {

    fetch("cart?book=" + item)
    .then(response => response.text())
    .then(data => {
        alert(item + " added to cart!");
    });

}