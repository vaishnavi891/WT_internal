<%@ page import="java.util.*" %>

<%
ArrayList<String> cart =
    (ArrayList<String>) session.getAttribute("cart");
%>

<h2>Your Cart</h2>

<%
if (cart == null || cart.isEmpty()) {
%>
    <p>Cart is empty</p>
<%
} else {
    for (String item : cart) {
%>
        <p><%= item %></p>
<%
    }
}
%>

<a href="shipping.jsp">Proceed to Checkout</a>